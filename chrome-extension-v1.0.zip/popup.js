document.addEventListener('DOMContentLoaded', () => {
  const listElement = document.getElementById('list');
  const clearBtn = document.getElementById('clearBtn');
  const togglePauseBtn = document.getElementById('togglePauseBtn');
  // const syncBtn = document.getElementById('syncBtn');
  const quickPauseBtn = document.getElementById('quickPauseBtn');
  const colorPicker = document.getElementById('colorPicker');
  const searchInput = document.getElementById('searchInput');
  const siteFilter = document.getElementById('siteFilter');
  
  // Time Management Elements
  const timeRange = document.getElementById('timeRange');
  const customDateInputs = document.getElementById('customDateInputs');
  const dateStart = document.getElementById('dateStart');
  const dateEnd = document.getElementById('dateEnd');
  const applyTimeFilterBtn = document.getElementById('applyTimeFilterBtn');
  const deleteTimeFilterBtn = document.getElementById('deleteTimeFilterBtn');
  const toggleAdvancedBtn = document.getElementById('toggleAdvancedBtn');
  const advancedOptions = document.getElementById('advancedOptions');

  let activeTimeFilter = { type: 'all' };

  loadHighlights();
  updatePauseButton();
  loadColor();

  // Save color preference when changed
  colorPicker.addEventListener('change', (e) => {
    chrome.storage.local.set({ userColor: e.target.value });
  });

  // Filter list when search or dropdown changes
  searchInput.addEventListener('input', loadHighlights);
  siteFilter.addEventListener('change', loadHighlights);

  // Toggle Advanced Options
  toggleAdvancedBtn.addEventListener('click', () => {
    if (advancedOptions.style.display === 'block') {
      advancedOptions.style.display = 'none';
      toggleAdvancedBtn.innerHTML = 'Show Advanced Options &#9662;';
    } else {
      advancedOptions.style.display = 'block';
      toggleAdvancedBtn.innerHTML = 'Hide Advanced Options &#9652;';
    }
  });

  // Time Range UI Logic
  timeRange.addEventListener('change', () => {
    const val = timeRange.value;
    if (val === 'range' || val === 'before') {
      customDateInputs.classList.add('visible');
      dateStart.style.display = (val === 'range') ? 'block' : 'none';
    } else {
      customDateInputs.classList.remove('visible');
    }
  });

  applyTimeFilterBtn.addEventListener('click', () => {
    activeTimeFilter = {
      type: timeRange.value,
      start: getLocalMidnightTime(dateStart.value),
      end: getLocalMidnightTime(dateEnd.value)
    };
    loadHighlights();
  });

  deleteTimeFilterBtn.addEventListener('click', () => {
    const filterConfig = {
      type: timeRange.value,
      start: getLocalMidnightTime(dateStart.value),
      end: getLocalMidnightTime(dateEnd.value)
    };

    if (filterConfig.type === 'all' && !confirm("This will delete ALL highlights. Are you sure?")) return;
    if (filterConfig.type !== 'all' && !confirm("Delete all highlights matching the selected time range?")) return;

    performTimeBasedDelete(filterConfig);
  });

  clearBtn.addEventListener('click', () => {
    if(confirm("Are you sure you want to delete all highlights?")) {
      chrome.storage.local.set({ highlights: [] }, () => {
        loadHighlights();
      });
    }
  });

  /*
  syncBtn.addEventListener('click', () => {
    chrome.storage.local.get({ highlights: [] }, (result) => {
      const highlights = result.highlights;
      if (!highlights || highlights.length === 0) {
        alert("No highlights to sync.");
        return;
      }

      // TODO: Replace with your actual Cloud Function or Backend API URL
      // Recommended: Firebase Cloud Functions or AWS Lambda for cost-effectiveness
      const CLOUD_API_URL = "https://your-cloud-service-endpoint.com/api/sync";
      
      const originalText = syncBtn.textContent;
      syncBtn.textContent = "Syncing...";
      syncBtn.disabled = true;

      fetch(CLOUD_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ highlights, timestamp: Date.now() })
      })
      .then(res => {
        if (res.ok) alert("Successfully synced to cloud!");
        else alert("Sync failed. Server responded with " + res.status);
      })
      .catch(err => alert("Network error: " + err.message))
      .finally(() => {
        syncBtn.textContent = originalText;
        syncBtn.disabled = false;
      });
    });
  });
  */

  quickPauseBtn.addEventListener('click', () => {
    chrome.storage.local.get({ isPaused: false }, (result) => {
      const newState = !result.isPaused;
      chrome.storage.local.set({ isPaused: newState }, () => {
        updatePauseButton();
      });
    });
  });

  togglePauseBtn.addEventListener('click', () => {
    chrome.storage.local.get({ isPaused: false }, (result) => {
      const newState = !result.isPaused;
      chrome.storage.local.set({ isPaused: newState }, () => {
        updatePauseButton();
      });
    });
  });

  function updatePauseButton() {
    chrome.storage.local.get({ isPaused: false }, (result) => {
      if (result.isPaused) {
        togglePauseBtn.textContent = "Resume Tracking";
        togglePauseBtn.classList.add('resume-mode');
        
        quickPauseBtn.textContent = "\u25B6";
        quickPauseBtn.title = "Resume Tracking";
        quickPauseBtn.style.color = "#137333";
      } else {
        togglePauseBtn.textContent = "Pause Tracking";
        togglePauseBtn.classList.remove('resume-mode');
        
        quickPauseBtn.textContent = "\u23F8";
        quickPauseBtn.title = "Pause Tracking";
        quickPauseBtn.style.color = "#5f6368";
      }
    });
  }

  function loadColor() {
    chrome.storage.local.get({ userColor: '#ffff00' }, (result) => {
      colorPicker.value = result.userColor;
    });
  }

  function loadHighlights() {
    chrome.storage.local.get({ highlights: [] }, (result) => {
      const highlights = result.highlights;
      listElement.innerHTML = '';
      
      // 1. Populate Site Filter Dropdown (only if needed to avoid resetting selection)
      updateSiteFilterOptions(highlights);

      // 2. Filter Data based on inputs
      const searchText = searchInput.value.toLowerCase();
      const selectedSite = siteFilter.value;
      const now = Date.now();

      const filteredHighlights = highlights.filter(item => {
        const textMatch = item.text.toLowerCase().includes(searchText);
        let urlMatch = false;
        try {
          urlMatch = new URL(item.url).hostname.toLowerCase().includes(searchText);
        } catch(e) {}

        let siteMatch = true;
        if (selectedSite) {
          try {
            siteMatch = new URL(item.url).hostname === selectedSite;
          } catch(e) { siteMatch = false; }
        }

        // Time Filtering
        let timeMatch = true;
        const itemTime = getItemTimestamp(item);
        
        switch (activeTimeFilter.type) {
          case 'last_hour':
            timeMatch = itemTime > (now - 3600000);
            break;
          case 'last_24h':
            timeMatch = itemTime > (now - 86400000);
            break;
          case 'last_week':
            timeMatch = itemTime > (now - 604800000);
            break;
          case 'range':
            if (activeTimeFilter.start && activeTimeFilter.end) {
              // End date should be inclusive of that day (23:59:59)
              const endOfDay = activeTimeFilter.end + 86400000 - 1;
              timeMatch = itemTime >= activeTimeFilter.start && itemTime <= endOfDay;
            }
            break;
          case 'before':
            if (activeTimeFilter.end) {
              timeMatch = itemTime < activeTimeFilter.end;
            }
            break;
        }

        return (textMatch || urlMatch) && siteMatch && timeMatch;
      });

      if (filteredHighlights.length === 0) {
        listElement.innerHTML = '<p style="text-align:center; color:#777;">No matching highlights found.</p>';
        return;
      }

      // Show newest first
      filteredHighlights.reverse().forEach(item => {
        const div = document.createElement('div');
        div.className = 'highlight-item';
        // Use the saved color for the border indicator
        div.style.borderLeftColor = item.color || '#ffff00';

        let shortUrl = item.url;
        try {
          const urlObj = new URL(item.url);
          shortUrl = urlObj.hostname + (urlObj.pathname.length > 15 ? urlObj.pathname.substring(0, 15) + '...' : urlObj.pathname);
        } catch(e) {}

        div.innerHTML = `
          <button class="delete-btn" title="Delete this highlight">&times;</button>
          <div class="text-content">"${escapeHtml(item.text)}"</div>
          <div class="meta">
            <span>${item.date}</span>
            <a href="${item.url}" target="_blank" title="${item.url}">Source</a>
          </div>
        `;

        // Add delete functionality
        div.querySelector('.delete-btn').addEventListener('click', () => {
          deleteHighlight(item);
        });

        listElement.appendChild(div);
      });
    });
  }

  function updateSiteFilterOptions(highlights) {
    // Get all unique hostnames
    const sites = new Set();
    highlights.forEach(h => {
      try { sites.add(new URL(h.url).hostname); } catch(e) {}
    });

    // If the number of options hasn't changed (approx check), skip rebuilding to prevent UI flicker
    // But strictly, we should rebuild to ensure correctness. We just need to preserve selection.
    const currentSelection = siteFilter.value;
    
    // Clear existing options except the first "All Sites"
    while (siteFilter.options.length > 1) {
      siteFilter.remove(1);
    }

    Array.from(sites).sort().forEach(site => {
      const option = document.createElement('option');
      option.value = site;
      option.textContent = site;
      if (site === currentSelection) option.selected = true;
      siteFilter.appendChild(option);
    });
  }

  function performTimeBasedDelete(filterConfig) {
    chrome.storage.local.get({ highlights: [] }, (result) => {
      const now = Date.now();
      const keptHighlights = result.highlights.filter(item => {
        const itemTime = getItemTimestamp(item);
        let shouldDelete = false;

        switch (filterConfig.type) {
          case 'all': shouldDelete = true; break;
          case 'last_hour': shouldDelete = itemTime > (now - 3600000); break;
          case 'last_24h': shouldDelete = itemTime > (now - 86400000); break;
          case 'last_week': shouldDelete = itemTime > (now - 604800000); break;
          case 'range':
            if (filterConfig.start && filterConfig.end) {
              const endOfDay = filterConfig.end + 86400000 - 1;
              shouldDelete = itemTime >= filterConfig.start && itemTime <= endOfDay;
            }
            break;
          case 'before':
            if (filterConfig.end) {
              shouldDelete = itemTime < filterConfig.end;
            }
            break;
        }
        return !shouldDelete; // Keep items that should NOT be deleted
      });

      chrome.storage.local.set({ highlights: keptHighlights }, () => {
        loadHighlights();
        alert("Deletion complete.");
      });
    });
  }

  function getLocalMidnightTime(dateString) {
    if (!dateString) return null;
    const parts = dateString.split('-');
    return new Date(parts[0], parts[1] - 1, parts[2]).getTime();
  }

  function getItemTimestamp(item) {
    if (item.timestamp) return item.timestamp;
    // Fallback for old items without timestamp
    const d = new Date(item.date);
    return isNaN(d.getTime()) ? 0 : d.getTime();
  }

  function deleteHighlight(itemToDelete) {
    chrome.storage.local.get({ highlights: [] }, (result) => {
      // Filter out the item that matches text, url, and date
      const newHighlights = result.highlights.filter(h => 
        !(h.text === itemToDelete.text && h.url === itemToDelete.url && h.date === itemToDelete.date)
      );
      chrome.storage.local.set({ highlights: newHighlights }, () => {
        loadHighlights(); // Reload the list
      });
    });
  }

  // Basic security: prevent XSS by escaping HTML
  function escapeHtml(text) {
    if (!text) return text;
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
  }
});
